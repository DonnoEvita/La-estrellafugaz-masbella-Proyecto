const noButton = document.getElementById("no");

const yesButton = document.getElementById("yes");

const reactionGif = document.getElementById("reactionGif");

const mainGif = document.getElementById("mainGif");

noButton.addEventListener("click", () => {

    let currentSize = parseFloat(window.getComputedStyle(noButton).fontSize);

    let yesSize = parseFloat(window.getComputedStyle(yesButton).fontSize);

    

    if (currentSize > 5) {  

        noButton.style.fontSize = (currentSize * 0.8) + "px";  

        yesButton.style.fontSize = (yesSize * 1.2) + "px";  

    }

    if (currentSize < 6) {

        noButton.style.display = "none"; 

    }

    // Ocultar el GIF principal

    mainGif.style.display = "none";

    // Cambia el GIF cuando tocan "No"

    reactionGif.src = "https://media.giphy.com/media/wfS4vDyVsASQygl4mN/giphy.gif";  

    reactionGif.style.display = "block";

});

yesButton.addEventListener("click", () => {

    alert("SIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIUIIUIIIIIIIIIIIIIIIIIIIIIISBXXKX TKMMMMM😭😭😭  🫂💕");

    

    // Ocultar el GIF principal

    mainGif.style.display = "none";

    // Cambia el GIF cuando tocan "Sí"

    reactionGif.src = "https://media.giphy.com/media/IzXiddo2twMmdmU8Lv/giphy.gif";  

    reactionGif.style.display = "block";

});